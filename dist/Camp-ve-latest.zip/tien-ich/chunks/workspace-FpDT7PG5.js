import{o,k as t}from"./styles-D4Pj-rTv.js";import{P as e}from"./Popup-DN9ODsND.js";o.createRoot(document.getElementById("root")).render(t.jsx(e,{workspace:!0}));
