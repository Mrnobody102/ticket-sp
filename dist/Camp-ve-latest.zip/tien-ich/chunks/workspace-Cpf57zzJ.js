import{o,k as t}from"./styles-vBf7BNm7.js";import{P as e}from"./Popup-TytIzFFI.js";o.createRoot(document.getElementById("root")).render(t.jsx(e,{workspace:!0}));
