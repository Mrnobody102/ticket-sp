import{o,k as t}from"./styles-Dltb3DgK.js";import{P as e}from"./Popup-DT84dkni.js";o.createRoot(document.getElementById("root")).render(t.jsx(e,{}));
