import{o,k as t}from"./styles-B7tDL5xN.js";import{P as e}from"./Popup-CpD7Nm6Z.js";o.createRoot(document.getElementById("root")).render(t.jsx(e,{}));
