import{o,k as t}from"./styles-Bp8vJnMW.js";import{P as e}from"./Popup-Bxn2qxsQ.js";o.createRoot(document.getElementById("root")).render(t.jsx(e,{}));
