import{o,k as t}from"./styles-BZ2VzfgV.js";import{P as e}from"./Popup-BpCvlrca.js";o.createRoot(document.getElementById("root")).render(t.jsx(e,{workspace:!0}));
