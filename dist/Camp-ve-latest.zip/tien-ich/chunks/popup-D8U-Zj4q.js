import{o,k as t}from"./styles-BILymKaq.js";import{P as e}from"./Popup-DFrgZwKX.js";o.createRoot(document.getElementById("root")).render(t.jsx(e,{}));
