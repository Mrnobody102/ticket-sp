import{o,k as t}from"./styles-C2GC8tVX.js";import{P as e}from"./Popup-DuDlWIx_.js";o.createRoot(document.getElementById("root")).render(t.jsx(e,{workspace:!0}));
