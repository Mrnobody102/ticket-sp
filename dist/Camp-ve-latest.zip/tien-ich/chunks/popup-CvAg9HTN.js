import{o,k as t}from"./styles-9eFR-jlC.js";import{P as e}from"./Popup-CzSfcc4z.js";o.createRoot(document.getElementById("root")).render(t.jsx(e,{}));
